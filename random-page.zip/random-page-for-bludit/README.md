# random-page-for-bludit

Adding random text feature to Bludit.

## Credits
Coded: eren.games
Published: agg1401
